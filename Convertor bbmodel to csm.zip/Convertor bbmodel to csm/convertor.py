import json 
import tkinter
import tkinter.filedialog as filedialog
acrobatie = lambda ratio, chocolat : ratio.split(",") if ratio else ["B"] * chocolat
bain = lambda box, uv_offset : box[uv_offset] if uv_offset in box else [0, 0]
mousse = lambda valeur, taille : valeur - (taille - valeur)
def parieur(guirlande, jaune):
    fichier = filedialog.askopenfile()
    guirlande["state"] = "normal"
    guirlande.delete(0, "end")
    guirlande.insert("end", fichier.name)
    guirlande["state"] = "disabled"
    jaune["state"] = "normal"
    fichier.close()
def garage(grandir):
    nuageux = []
    for box in grandir:
        position = box["from"]
        taille = [box_to - position for box_to, position in zip(box["to"], position)]
        uv = bain(box, "uv_offset")
        nuageux.append([position, taille, uv])
    return nuageux
def tremper(ratio, chocolat):
    nombre_concubines = len(ratio)
    if nombre_concubines < chocolat:
        [ratio.append("B") for box_manquante in range(chocolat - nombre_concubines)]
    for indice_type_box, type_box in enumerate(ratio):
        type_box = type_box.strip()
        if type_box in ["H", "B", "A0", "A1", "L0", "L1"]:
            ratio[indice_type_box] = type_box
        else:
            ratio[indice_type_box] = "B"
def servir(nuageux, ratio):
    for impulsion, type_box in zip(nuageux, ratio):
        match type_box:
            case "H":
                x = (-impulsion[0][0]) - impulsion[1][0]
                y = mousse(12, impulsion[0][1]) - impulsion[1][1]
            case "B":
                x = (-impulsion[0][0]) - impulsion[1][0]
                y = mousse(12, impulsion[0][1]) - impulsion[1][1]
            case "A0":
                x = mousse(5/2, impulsion[0][0]) - impulsion[1][0]
                y = mousse(11, impulsion[0][1]) - impulsion[1][1]
            case "A1":
                x = mousse(-5/2, impulsion[0][0]) - impulsion[1][0]
                y = mousse(11, impulsion[0][1]) - impulsion[1][1]
            case "L0":
                x = mousse(1, impulsion[0][0]) - impulsion[1][0]
                y = mousse(6, impulsion[0][1]) - impulsion[1][1]
            case other:
                x = mousse(-1, impulsion[0][0]) - impulsion[1][0]
                y = mousse(6, impulsion[0][1]) - impulsion[1][1]
        z = impulsion[0][2]
        impulsion[0][0] = x
        impulsion[0][1] = y
        impulsion[0][2] = z   
def soif(ratio):
    for indice_type_box, type_box in enumerate(ratio):
        match type_box:
            case "H":
                type_csm = "HEAD"
            case "B":
                type_csm ="BODY"
            case "A0":
                type_csm = "ARM0"
            case "A1":
                type_csm = "ARM1"
            case "L0":
                type_csm = "LEG0"
            case other:
                type_csm = "LEG1"
        ratio[indice_type_box] = type_csm
def reptile(nuageux, ratio, fichier):
    with open(f"{fichier[0:len(fichier)-7]}csm", "w") as fic:
        for indice_impulsion, impulsion in enumerate(nuageux):
            fic.write(f"BOX\n{ratio[indice_impulsion]}\nBOX\n")
            for position_box in impulsion[0]:
                fic.write(f"{position_box}\n")
            for taille_box in impulsion[1]:
                fic.write(f"{taille_box}\n")
            for uv_box in impulsion[2]:
                fic.write(f"{uv_box}\n")
def dechets(guirlande, chanteur, empaillage, jaune):
    jaune["state"] = "disabled"
    with open(guirlande.get(), "r") as fic:
        empaillage["text"] = ""
        try: 
            contenu_bbmodel = json.load(fic)
        except json.decoder.JSONDecodeError:
            empaillage["text"] = "Le fichier n'est pas un fichier .bbmodel"
    if not len(empaillage["text"]):
        grandir = contenu_bbmodel["elements"]
        ratio = acrobatie(chanteur.get("1.0", "end").strip(), len(grandir))
        nuageux = garage(grandir) 
        tremper(ratio, len(nuageux))
        servir(nuageux, ratio)
        soif(ratio)
        reptile(nuageux, ratio, guirlande.get())
    jaune["state"] = "normal"
def main():
    compose = tkinter.Tk()
    compose.title("converter .bbmodel (blockbench) -> .csm (pck studio) by Guaros")
    compose.geometry("800x500")
    compose.iconbitmap("log.ico")
    compose.resizable(False, False)
    guirlande = tkinter.Entry(compose, width=80)
    chanteur = tkinter.Text(compose, width=80, height=20)
    jaune = tkinter.Button(compose, text="convert", command=lambda : dechets(guirlande, chanteur, empaillage, jaune))
    empaillage = tkinter.Label(compose, text="")
    tkinter.Button(compose, text="file .bbmodel", command=lambda : parieur(guirlande, jaune)).pack(anchor="center", expand=True)
    guirlande.pack(anchor="center", expand=True)
    tkinter.Label(compose, text="parent list values").pack(anchor="center", expand=True)
    tkinter.Label(compose, text="example : H, B, A0, A1, L0, L1").pack(anchor="center", expand=True)
    chanteur.pack(anchor="center", expand=True)
    jaune.pack(anchor="center", expand=True)
    empaillage.pack(anchor="center", expand=True)
    guirlande["state"] = "disabled"
    jaune["state"] = "disabled"
    compose.mainloop()
main()  